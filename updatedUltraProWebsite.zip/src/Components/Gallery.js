import React from "react";
import "../Styles/main.css";
import PlanEvents from "./PlanEvents";
function Gallery() {
  return (
    <div>
      <PlanEvents />
    </div>
  );
}
export default Gallery;
