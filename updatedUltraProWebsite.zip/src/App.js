import React from "react";
import Footer from "./Components/Footer";
function App() {
  return (
    <React.Fragment>
      <Footer />
    </React.Fragment>
  );
}

export default App;
