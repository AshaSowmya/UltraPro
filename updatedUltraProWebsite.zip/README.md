## A UltraPRo Company Task
---
To get started with the project, follow the steps below:

1. **Clone the repository**

   Open your terminal and run the following command to clone the repository:

   ```bash
   git clone https://github.com/AshaSowmya/UltraPro.git

2.**Navigate into the project directory**
   
   cd UltraPro

3.**Install dependencies**
 
   npm install

